
import React from 'react';

export const MeupluginPage = () => {
  return <div>Olá! Este é o plugin plugintesteons funcionando.</div>;
};
